package filesystem;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.NoSuchElementException;
import structures.Queue;

/**
 * An iterator to perform a level order traversal of part of a 
 * filesystem. A level-order traversal is equivalent to a breadth-
 * first search.
 * 
 * @author liberato
 *
 */
public class LevelOrderIterator extends FileIterator<File> {	
	/**
	 * Instantiate a new LevelOrderIterator, rooted at the rootNode.
	 * @param rootNode
	 * @throws FileNotFoundException if the rootNode does not exist
	 */
	File rootFile;
	Queue<File> file = new Queue<File>();
	public LevelOrderIterator(File rootNode) throws FileNotFoundException {
		// TODO 1
		if(!rootNode.exists()){
			throw new FileNotFoundException();
		}else{
			rootFile = rootNode;
			file.enqueue(rootFile);
		}
	}
	
	@Override
	public boolean hasNext() {
		if(file.isEmpty()){
			return false;
		}
		else return true;
	}

	@Override
	public File next() throws NoSuchElementException {	
		if(hasNext()){
			File answer =  file.dequeue();
			if(answer.isDirectory()){
				for(File files: answer.listFiles()){
					file.enqueue(files);
				}
			}
			return answer;
		}
		else if(!rootFile.exists())
			throw new NoSuchElementException();
		else{
			throw new NoSuchElementException();
		}
	}


	@Override
	public void remove() {
		// Leave this one alone.
		throw new UnsupportedOperationException();		
	}

}
