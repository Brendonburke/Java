package structures;

import java.util.NoSuchElementException;

public class Queue<T> implements UnboundedQueueInterface<T> {
	Node<T> head;
	Node<T> tail;
	int size;
	public Queue() {		
            // TODO 1
		head= null;
		tail=null;
		size=0;
    }
	
	public Queue(Queue<T> other) {
            // TODO 2
	Node<T> temp=other.head;
	size=0;
	while(temp!=null){
		enqueue(temp.getData());
		temp=temp.getNext();
	}
	}
	
	@Override
	public boolean isEmpty() {
            // TODO 3
		if (head!= null){
			return false;
		}
		else return true;
	}

	@Override
	public int size() {
            // TODO 4
            return size;
	}

	@Override
	public void enqueue(T element) {
            // TODO 5
		Node<T> newNode = new Node<T>(element);
		if(!isEmpty()){
			tail.setNext(newNode);
			tail=newNode;
			
		}
		else{
			head=newNode;
			tail=newNode;
		}
		size++;
	}

	@Override
	public T dequeue() throws NoSuchElementException {
            // TODO 6
		T info;
        if(size==1){
        	info=head.getData();
        	tail=null;
        	head=null;
        	size--;
        }
        else if(isEmpty()){
        	throw new NoSuchElementException("Queue is Empty");
        }
        else{
        	info=head.getData();
        	head=head.getNext();
        	size--;
        }
        return info;
	}

	@Override
	public T peek() throws NoSuchElementException {
            // TODO 7
		if(!isEmpty()){
			return head.getData();
        }
		else{
			throw new NoSuchElementException("Queue is Empty");
		}
	}

	@Override
	public UnboundedQueueInterface<T> reversed() {
            // TODO 8
		if(size==1 || isEmpty()){
			return this;
		}
		else{
			Queue<T> reverse = new Queue<T>(this);
			T temp=reverse.dequeue();
			reverse.enqueue(temp);
			while(reverse.head!=temp){
				T info=reverse.dequeue();
				reverse.enqueue(info);						
			}
			return reverse;
		}
	}
}
